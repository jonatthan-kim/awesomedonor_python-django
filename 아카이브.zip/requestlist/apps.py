from django.apps import AppConfig


class RequestlistConfig(AppConfig):
    name = 'requestlist'
