from django.contrib import admin
from .models import Member, ReceiverLike

admin.site.register(ReceiverLike)
admin.site.register(Member)
