from django.apps import AppConfig


class ReceiverlistConfig(AppConfig):
    name = 'receiverlist'
