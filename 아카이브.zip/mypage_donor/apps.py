from django.apps import AppConfig


class MypageDonorConfig(AppConfig):
    name = 'mypage_donor'
