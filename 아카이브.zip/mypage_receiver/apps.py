from django.apps import AppConfig


class MypageReceiverConfig(AppConfig):
    name = 'mypage_receiver'
